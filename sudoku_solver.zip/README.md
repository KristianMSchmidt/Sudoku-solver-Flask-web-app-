# Sudoku-solver
Automatic sudoku-solver using AC-3 and backtracking algorithms.
Web app made with Flask.
